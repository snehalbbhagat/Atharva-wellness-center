const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const chatBox = document.getElementById("chat-box");

const wellnessReplies = [
  "🌿 Thank you for asking! Our wellness coach will contact you soon!",
  "💪 We provide both weight gain and weight loss programs!",
  "🧘 You can join by filling out the registration form above!",
  "💚 Welcome to Atharva Wellness Family — your health journey begins here!",
];

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const userMsg = chatInput.value.trim();
  if (!userMsg) return;

  addMessage("user", userMsg);
  chatInput.value = "";

  const botReply = wellnessReplies[Math.floor(Math.random() * wellnessReplies.length)];
  setTimeout(() => addMessage("bot", botReply), 500);
});

function addMessage(type, text) {
  const div = document.createElement("div");
  div.className = type === "user" ? "chat-user" : "chat-bot";
  div.innerText = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

const style = document.createElement("style");
style.innerHTML = `
.chat-user { text-align: right; margin: 0.5rem 0; }
.chat-bot { text-align: left; margin: 0.5rem 0; }
.chat-user::before { content: "You: "; font-weight: bold; }
.chat-bot::before { content: "Coach: "; font-weight: bold; }
`;
document.head.appendChild(style);
